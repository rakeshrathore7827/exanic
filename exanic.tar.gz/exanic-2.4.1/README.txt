For installation instructions, refer to 
https://exablaze.com/docs/exanic/user-guide/installation/installation/

